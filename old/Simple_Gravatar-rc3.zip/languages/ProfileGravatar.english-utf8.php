<?php

global $txt;

$txt['gravatar'] = 'Gravatar';
$txt['gravatar_profile'] = 'Gravatar';
$txt['gravatar_profile_description'] = 'Change your gravatar at <em>Gravatar.com</em>';