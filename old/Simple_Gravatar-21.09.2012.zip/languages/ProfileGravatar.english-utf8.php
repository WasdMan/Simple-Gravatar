<?php

global $txt;

$txt['gravatar_profile'] = 'Gravatar';
$txt['gravatar_profile_description'] = 'Change your avatar at <em>Gravatar.com</em>';