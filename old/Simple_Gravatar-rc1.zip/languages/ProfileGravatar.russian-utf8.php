<?php

global $txt;

$txt['gravatar'] = 'Gravatar';
$txt['gravatar_profile'] = 'Граватар';
$txt['gravatar_profile_description'] = 'Вы можете изменить свой глобальный аватар на сайте <em>Gravatar.com</em>';